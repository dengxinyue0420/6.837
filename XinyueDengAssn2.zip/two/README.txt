Submission:
1. How to compile in the root folder:
   %mkdir build&&cd build
   %cmake ..
   %make clean install
   
   The executable is inside ./inst/. The name is a1.

2. No Collaborator

3. Get help on Piazza
4. Currently, I didn't find any issues.
5. I didn't do any extra credit.
6. I think most office hour happen when there are classes, could there be any more options? I cannot go to neither of these.
